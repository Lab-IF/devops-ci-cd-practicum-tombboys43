# 💭 Reflection – Praktikum DevOps Pertemuan 01

Pada praktikum pertemuan pertama ini, saya mempelajari pentingnya menyiapkan development environment yang terstandarisasi sebelum memulai proses pengembangan aplikasi. Instalasi dan konfigurasi Git, Docker Desktop, serta Visual Studio Code menjadi langkah awal yang sangat penting dalam mendukung workflow DevOps.

Saya memahami bahwa DevOps bukan hanya tentang penggunaan tools, tetapi juga tentang budaya kerja yang menekankan kolaborasi, otomatisasi, dan efisiensi. Dengan menggunakan Git sebagai version control, saya dapat mengelola perubahan kode dengan lebih terstruktur. Docker membantu dalam menjalankan aplikasi di environment yang konsisten, sehingga mengurangi masalah “works on my machine”. Visual Studio Code dengan extension seperti Docker, GitLens, dan YAML sangat membantu dalam meningkatkan produktivitas.

Melalui praktikum ini, saya menyadari bahwa setup environment yang benar akan mempermudah proses CI/CD di tahap berikutnya. Saya juga semakin memahami bagaimana peran DevOps sangat penting dalam dunia industri, terutama dalam mempercepat proses deployment dan menjaga stabilitas sistem.

Harapan saya ke depan adalah dapat:
- Menguasai konsep CI/CD secara lebih mendalam.
- Mampu membuat pipeline otomatis menggunakan GitHub Actions.
- Mengimplementasikan Docker dalam proyek nyata.
- Meningkatkan kesiapan saya sebagai software developer yang memahami praktik DevOps modern.

Praktikum ini menjadi fondasi awal yang sangat penting untuk memahami alur kerja DevOps secara menyeluruh.
