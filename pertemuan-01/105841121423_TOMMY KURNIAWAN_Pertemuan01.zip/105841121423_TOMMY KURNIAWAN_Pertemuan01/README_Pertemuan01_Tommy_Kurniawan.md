# 📘 Laporan Praktikum DevOps -- Pertemuan 01

## Setup Development Environment

**Nama:** Tommy Kurniawan\
**NIM:** 105841121423\
**Mata Kuliah:** DevOps CI/CD

------------------------------------------------------------------------

## 🧠 1. Penjelasan Tentang DevOps

### ✅ Apa itu DevOps?

DevOps adalah pendekatan atau budaya kerja dalam pengembangan perangkat
lunak yang menggabungkan tim Development (Dev) dan Operations (Ops).\
Tujuan utama DevOps adalah meningkatkan kolaborasi, otomatisasi, dan
efisiensi dalam proses pengembangan hingga deployment aplikasi.

DevOps tidak hanya tentang tools, tetapi juga tentang mindset kerja yang
berfokus pada:

-   Kolaborasi tim\
-   Otomatisasi proses\
-   Continuous Integration (CI)\
-   Continuous Deployment (CD)\
-   Monitoring berkelanjutan

------------------------------------------------------------------------

### 🎯 Mengapa DevOps Penting?

1.  Mempercepat Proses Rilis Software\
2.  Mengurangi Risiko Error\
3.  Meningkatkan Kolaborasi Tim\
4.  Skalabilitas dan Stabilitas Sistem

------------------------------------------------------------------------

## 🖥 2. Setup Development Environment

### 🔹 Git

Perintah:

``` bash
git --version
```

Screenshot: screenshots/git-version.png

------------------------------------------------------------------------

### 🔹 Docker Desktop

Perintah:

``` bash
docker --version
```

Screenshot: screenshots/docker-version.png

------------------------------------------------------------------------

### 🔹 Visual Studio Code

Extension: - Docker\
- GitLens\
- YAML

Screenshot: screenshots/vscode-setup.png

------------------------------------------------------------------------

## 💭 3. Reflection

Harapan saya dalam mengikuti praktikum DevOps ini adalah memahami konsep
DevOps secara praktik, mampu menggunakan Docker untuk containerisasi
aplikasi, menguasai integrasi Git dan GitHub, serta memahami
implementasi CI/CD untuk kebutuhan industri.

------------------------------------------------------------------------

## 📂 Struktur Folder Submission

105841121423_TommyKurniawan_Pertemuan01/ │ ├── README.md ├──
screenshots/ │ ├── git-version.png │ ├── docker-version.png │ └──
vscode-setup.png └── reflection.md
